
<p>Dear <?php echo e($user->first_name ?? 'Student'); ?>,</p>

<p>Your one-time password (OTP) for <?php echo e($purpose); ?> is:</p>

<h2 style="letter-spacing:4px;font-family:monospace;"><?php echo e($code); ?></h2>

<p>This code will expire in <?php echo e(config('auth.otp.lifetime_minutes', 10)); ?> minutes.</p>

<p>If you did not request this, you can safely ignore this email.</p><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/emails/otp.blade.php ENDPATH**/ ?>