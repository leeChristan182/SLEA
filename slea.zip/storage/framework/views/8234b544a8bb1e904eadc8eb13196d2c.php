<?php
    $categoryKey = 'conduct';
    $category = App\Models\RubricCategory::with(['sections.subsections.options'])
        ->where('key', $categoryKey)
        ->first();
?>

<div class="rubric-section">
    <h4 class="rubric-heading">V. GOOD CONDUCT</h4>

    <p class="rubric-category-description">
        Refers to the student's behavior during their stay in the university.
    </p>

    <?php if(!$category || $category->sections->isEmpty()): ?>
        <p class="text-muted text-center">No sections found for this category.</p>
    <?php else: ?>
        <?php $__currentLoopData = $category->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="table-wrap">
                <table class="manage-table">
                    <thead>
                        <tr>
                            <th>Section</th>
                            <th>Offense Type</th>
                            <th>Points</th>
                            <th>Evidence Needed</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $section->subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // fallback for evidence/notes
                                $evidenceSource = $sub->evidence_needed ?: $section->evidence;
                                $notesSource    = $sub->notes ?: $section->notes;

                                $options = $sub->options ?? collect();
                                $rowCount = max($options->count(), 1);
                                $printedSection = false;
                            ?>

                            <?php if($options->isNotEmpty()): ?>
                                
                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <?php if(!$printedSection): ?>
                                            <td rowspan="<?php echo e($rowCount); ?>"><strong><?php echo e($section->title); ?></strong></td>
                                            <?php $printedSection = true; ?>
                                        <?php endif; ?>

                                        
                                        <td><?php echo e($opt->label); ?></td>

                                        
                                        <td><?php echo e(rtrim(rtrim(number_format($opt->points, 2), '0'), '.')); ?></td>

                                        
                                        <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e($rowCount); ?>">
                                                <?php if(!empty($evidenceSource)): ?>
                                                    <div class="evidence-notes-content">
                                                        <?php $__currentLoopData = explode("\n", $evidenceSource); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(trim($line) !== ''): ?>
                                                                <?php if($i > 0): ?> <br><br> <?php endif; ?>
                                                                <?php echo e($line); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?> —
                                                <?php endif; ?>
                                            </td>

                                            
                                            <td rowspan="<?php echo e($rowCount); ?>">
                                                <?php if(!empty($notesSource)): ?>
                                                    <div class="evidence-notes-content">
                                                        <?php $__currentLoopData = explode("\n", $notesSource); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(trim($line) !== ''): ?>
                                                                <?php if($i > 0): ?> <br><br> <?php endif; ?>
                                                                <?php echo e($line); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?> —
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>

                                        
                                        <td>
                                            <div class="action-buttons-group">
                                                <button class="btn-edit" onclick="openEditRubricModal(
                                                    <?php echo e($opt->id); ?>,
                                                    <?php echo e($sub->sub_section_id); ?>,
                                                    '<?php echo e(addslashes($opt->label)); ?>',
                                                    <?php echo e($opt->points); ?>,
                                                    <?php echo e($opt->order_no); ?>,
                                                    '<?php echo e(addslashes($sub->notes ?? '')); ?>'
                                                )">
                                                    <i class="fas fa-edit"></i>
                                                </button>

                                                <button class="btn-delete" onclick="openDeleteRubricModal(
                                                    <?php echo e($opt->id); ?>,
                                                    'Good Conduct',
                                                    '<?php echo e(addslashes($opt->label)); ?>'
                                                )">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>
                                
                                <tr>
                                    <td><strong><?php echo e($section->title); ?></strong></td>
                                    <td><?php echo e($sub->sub_section); ?></td>
                                    <td>—</td>
                                    <td>—</td>
                                    <td>—</td>
                                    <td>—</td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/rubrics/sections/conduct.blade.php ENDPATH**/ ?>