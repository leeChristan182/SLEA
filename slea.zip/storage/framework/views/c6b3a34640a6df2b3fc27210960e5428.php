<?php $__env->startSection('title', 'System Monitoring & Logs'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <div class="page-header">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
                <div>
                    <h1>System Monitoring &amp; Logs</h1>
                    <p style="color: #6b7280; margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                        View recorded activities performed by admins, assessors, and students.
                    </p>
                </div>
                <form action="<?php echo e(route('admin.system-logs.clear')); ?>"
                      method="POST"
                      onsubmit="return confirm('Are you sure you want to clear ALL system logs?');"
                      style="margin: 0;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn-clear" style="background-color: #dc3545; color: white;">
                        <i class="fas fa-trash"></i> Clear All Logs
                    </button>
                </form>
            </div>
        </div>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        
        <div class="controls-section">
            <div class="filter-controls">
                <div class="filter-group">
                    <label for="roleFilter">User Role</label>
                    <select name="role" id="roleFilter" class="form-select">
                        <option value="">All Roles</option>
                        <?php $__currentLoopData = ['admin' => 'Admin', 'assessor' => 'Assessor', 'student' => 'Student']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if(request('role') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="activityFilter">Activity</label>
                    <select name="activity_type" id="activityFilter" class="form-select">
                        <option value="">All Activities</option>
                        <?php $__currentLoopData = ['Login', 'Logout', 'Create', 'Update', 'Delete']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>" <?php if(request('activity_type') === $type): echo 'selected'; endif; ?>>
                                <?php echo e($type); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="fromDate">From</label>
                    <input type="date"
                           name="from"
                           id="fromDate"
                           class="form-control"
                           value="<?php echo e(request('from')); ?>">
                </div>

                <div class="filter-group">
                    <label for="toDate">To</label>
                    <input type="date"
                           name="to"
                           id="toDate"
                           class="form-control"
                           value="<?php echo e(request('to')); ?>">
                </div>
            </div>

            <div class="search-controls">
                <div class="search-group">
                    <input
                        type="text"
                        name="q"
                        id="searchInput"
                        class="form-control"
                        placeholder="Search by user or description..."
                        value="<?php echo e(request('q')); ?>"
                    >
                    <button type="submit" form="filterForm" class="btn-search-maroon search-btn-attached" title="Search">
                        <i class="fas fa-search"></i>
                    </button>
                    <a href="<?php echo e(route('admin.system-logs.index')); ?>" class="btn-clear" title="Clear filters">
                        Clear
                    </a>
                </div>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('admin.system-logs.index')); ?>" id="filterForm" style="display: none;">
            <input type="hidden" name="role" id="roleHidden" value="<?php echo e(request('role')); ?>">
            <input type="hidden" name="activity_type" id="activityHidden" value="<?php echo e(request('activity_type')); ?>">
            <input type="hidden" name="from" id="fromHidden" value="<?php echo e(request('from')); ?>">
            <input type="hidden" name="to" id="toHidden" value="<?php echo e(request('to')); ?>">
            <input type="hidden" name="q" id="searchHidden" value="<?php echo e(request('q')); ?>">
        </form>

        
        <div class="submissions-table-container">
            <table class="table submissions-table">
                <thead>
                    <tr>
                        <th>Date &amp; Time</th>
                        <th>Role</th>
                        <th>User</th>
                        <th>Activity</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('Y-m-d g:i A')); ?></td>
                            <td class="text-capitalize"><?php echo e($log->user_role ?? 'N/A'); ?></td>
                            <td><?php echo e($log->user_name); ?></td>
                            <td><?php echo e($log->activity_type); ?></td>
                            <td><?php echo e($log->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                No logs found for the selected filters.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <?php if($logs->hasPages()): ?>
            <div class="pagination-container" data-pagination-container>
                <div class="pagination-info">
                    Showing <?php echo e($logs->firstItem() ?? 0); ?> – <?php echo e($logs->lastItem() ?? 0); ?>

                    of <?php echo e($logs->total()); ?> entries
                </div>

                <div class="unified-pagination">
                    <?php if($logs->onFirstPage()): ?>
                        <button class="btn-nav" disabled>
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                    <?php else: ?>
                        <a href="<?php echo e($logs->previousPageUrl()); ?>" class="btn-nav">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>

                    <span class="pagination-pages">
                        <?php
                            $currentPage = $logs->currentPage();
                            $lastPage = $logs->lastPage();
                            $start = max(1, $currentPage - 2);
                            $end = min($lastPage, $currentPage + 2);
                        ?>

                        <?php if($start > 1): ?>
                            <a href="<?php echo e($logs->url(1)); ?>" class="page-btn">1</a>
                            <?php if($start > 2): ?>
                                <span class="page-btn disabled">...</span>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php for($i = $start; $i <= $end; $i++): ?>
                            <?php if($i == $currentPage): ?>
                                <span class="page-btn active"><?php echo e($i); ?></span>
                            <?php else: ?>
                                <a href="<?php echo e($logs->url($i)); ?>" class="page-btn"><?php echo e($i); ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if($end < $lastPage): ?>
                            <?php if($end < $lastPage - 1): ?>
                                <span class="page-btn disabled">...</span>
                            <?php endif; ?>
                            <a href="<?php echo e($logs->url($lastPage)); ?>" class="page-btn"><?php echo e($lastPage); ?></a>
                        <?php endif; ?>
                    </span>

                    <?php if($logs->hasMorePages()): ?>
                        <a href="<?php echo e($logs->nextPageUrl()); ?>" class="btn-nav">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php else: ?>
                        <button class="btn-nav" disabled>
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </main>
</div>

<link rel="stylesheet" href="<?php echo e(asset('css/pending-submissions.css')); ?>">
<style>
    /* Prevent horizontal scrollbar */
    body {
        overflow-x: hidden !important;
    }

    .container {
        overflow-x: hidden !important;
        max-width: 100% !important;
    }

    .main-content {
        max-width: 100% !important;
        overflow-x: hidden !important;
        box-sizing: border-box !important;
    }

    /* System Monitoring Specific Styles */
    .page-header h1 {
        color: #7E0308;
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }

    body.dark-mode .page-header h1 {
        color: #F9BD3D;
    }

    /* Filter group width adjustments */
    .filter-group select,
    .filter-group input[type="date"] {
        width: 180px;
        max-width: 180px;
        min-width: 150px;
    }

    /* Search input width */
    .search-group .form-control {
        max-width: 350px;
    }

    /* Controls section - prevent overflow */
    .controls-section {
        max-width: 100% !important;
        overflow-x: hidden !important;
        flex-wrap: wrap !important;
    }

    /* Table container - prevent overflow */
    .submissions-table-container {
        max-width: 100% !important;
        overflow-x: auto !important;
        box-sizing: border-box !important;
    }

    .submissions-table {
        width: 100% !important;
        table-layout: auto !important;
    }

    /* Ensure table cells don't overflow */
    .submissions-table td,
    .submissions-table th {
        word-wrap: break-word;
        overflow-wrap: break-word;
        white-space: normal;
    }

    /* Specific column widths for better layout */
    .submissions-table th:nth-child(1),
    .submissions-table td:nth-child(1) {
        width: 15%;
        min-width: 150px;
    }

    .submissions-table th:nth-child(2),
    .submissions-table td:nth-child(2) {
        width: 10%;
        min-width: 80px;
    }

    .submissions-table th:nth-child(3),
    .submissions-table td:nth-child(3) {
        width: 20%;
        min-width: 150px;
    }

    .submissions-table th:nth-child(4),
    .submissions-table td:nth-child(4) {
        width: 12%;
        min-width: 100px;
    }

    .submissions-table th:nth-child(5),
    .submissions-table td:nth-child(5) {
        width: 43%;
        min-width: 200px;
    }

    /* Clear All Logs button styling */
    .btn-clear[style*="background-color: #dc3545"] {
        background-color: #dc3545 !important;
        color: white !important;
        border: none;
        border-radius: 6px;
        padding: 0.5rem 1rem;
        height: 38px;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 0.9rem;
        font-weight: 500;
    }

    .btn-clear[style*="background-color: #dc3545"]:hover {
        background-color: #c82333 !important;
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3);
    }

    body.dark-mode .btn-clear[style*="background-color: #dc3545"] {
        background-color: #dc3545 !important;
    }

    body.dark-mode .btn-clear[style*="background-color: #dc3545"]:hover {
        background-color: #bb2d3b !important;
    }

    /* Center main content */
    .main-content {
        margin-left: 260px !important;
        padding: 2rem !important;
        box-sizing: border-box !important;
    }

    @media (max-width: 768px) {
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>

<script>
    // Handle form submission
    document.addEventListener('DOMContentLoaded', function() {
        const roleFilter = document.getElementById('roleFilter');
        const activityFilter = document.getElementById('activityFilter');
        const fromDate = document.getElementById('fromDate');
        const toDate = document.getElementById('toDate');
        const searchInput = document.getElementById('searchInput');
        const filterForm = document.getElementById('filterForm');
        const searchBtn = document.querySelector('.btn-search-maroon[form="filterForm"]');

        // Sync visible inputs with hidden form inputs
        function syncFormInputs() {
            const roleHidden = document.getElementById('roleHidden');
            const activityHidden = document.getElementById('activityHidden');
            const fromHidden = document.getElementById('fromHidden');
            const toHidden = document.getElementById('toHidden');
            const searchHidden = document.getElementById('searchHidden');

            if (roleHidden && roleFilter) roleHidden.value = roleFilter.value;
            if (activityHidden && activityFilter) activityHidden.value = activityFilter.value;
            if (fromHidden && fromDate) fromHidden.value = fromDate.value;
            if (toHidden && toDate) toHidden.value = toDate.value;
            if (searchHidden && searchInput) searchHidden.value = searchInput.value;
        }

        // Handle search button click
        if (searchBtn && filterForm) {
            searchBtn.addEventListener('click', function(e) {
                e.preventDefault();
                syncFormInputs();
                filterForm.submit();
            });
        }

        // Auto-submit on filter change (optional - can be removed if you want manual submit only)
        // if (roleFilter) {
        //     roleFilter.addEventListener('change', function() {
        //         syncFormInputs();
        //         filterForm.submit();
        //     });
        // }

        // if (activityFilter) {
        //     activityFilter.addEventListener('change', function() {
        //         syncFormInputs();
        //         filterForm.submit();
        //     });
        // }
    });
</script>
<script src="<?php echo e(asset('js/admin_pagination.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/system-monitoring.blade.php ENDPATH**/ ?>