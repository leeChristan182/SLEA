<?php
    /** @var \Illuminate\Support\Collection|\App\Models\RubricCategory[] $categories */

    $leadershipCategory = $categories->firstWhere('key', 'leadership');

    // If leadershipSections is null, show all sections (for single page display)
    // Otherwise, show only the specified sections (for chunked display)
    if ($leadershipSections === null) {
        $sections = $leadershipCategory?->sections ?? collect();
    } else {
        $sections = $leadershipSections;
    }
?>

<div class="rubric-section" data-category="leadership">
    <h4 class="rubric-heading">I. LEADERSHIP EXCELLENCE</h4>

    <p class="rubric-category-description">
        This criterion covers the leadership experience of the applicant for having assumed
        elective/appointive positions in the campus/community organizations and having participated in
        co-curricular and extracurricular activities such as but not limited to competitions, conferences,
        seminar, workshops, etc.
    </p>

    <?php if($sections->isEmpty()): ?>
        <p class="text-muted text-center">No leadership sections found.</p>
    <?php else: ?>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $subsections = $section->subsections ?? collect();
            ?>

            <?php if($subsections->isNotEmpty()): ?>
                <div class="subsection mb-4">
                    <h5 class="subsection-title"><strong><?php echo e($section->title); ?></strong></h5>

                    <?php
                        // For section D (Training), combine all subsections into one table
                        $isTrainingSection =
                            strpos($section->title, 'Training') !== false ||
                            strpos($section->title, 'Seminars') !== false ||
                            strpos($section->title, 'Conferences') !== false;
                    ?>

                    <?php if($isTrainingSection): ?>
                        
                        <div class="table-wrap">
                            <table class="manage-table training-table">
                                <thead>
                                    <tr>
                                        <th>Subsection</th>
                                        <th>Position / Title</th>
                                        <th>Points</th>
                                        <th>Evidence Needed</th>
                                        <th>Notes</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            // score_params is already cast to array in the model
                                            $scoreParams = $subsection->score_params ?? [];
                                            $rate = $scoreParams['rate'] ?? null;
                                            $capPoints = $subsection->cap_points ?? null;

                                            // Prefer subsection-specific evidence/notes; fallback to section-level
                                            $rawEvidence = $subsection->evidence_needed ?: $section->evidence;
                                            $rawNotes = $subsection->notes ?: $section->notes;

                                            $evidenceLines = preg_split("/\r\n|\n|\r/", $rawEvidence ?? '');
                                            $notesLines = preg_split("/\r\n|\n|\r/", $rawNotes ?? '');
                                        ?>
                                        <tr>
                                            <td class="training-category"><strong><?php echo e($subsection->sub_section); ?></strong></td>
                                            <td class="training-position"><?php echo e($subsection->sub_section); ?></td>
                                            <td class="training-points">
                                                <?php if($rate): ?>
                                                    <span class="points-line">
                                                        <?php echo e(rtrim(rtrim(number_format($rate, 1), '0'), '.')); ?>/day
                                                    </span>
                                                    <?php if($capPoints): ?>
                                                        <br>
                                                        <span class="points-line">
                                                            (max <?php echo e(rtrim(rtrim(number_format($capPoints, 2), '0'), '.')); ?> points)
                                                        </span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>
                                            <td class="training-evidence">
                                                <?php if(!empty($rawEvidence)): ?>
                                                    <div class="evidence-notes-content">
                                                        <?php $__currentLoopData = $evidenceLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(trim($line) !== ''): ?>
                                                                <?php if($index > 0): ?>
                                                                    <br><br>
                                                                <?php endif; ?>
                                                                <?php echo e($line); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    Certificate of Attendance/Appreciation/Participation
                                                <?php endif; ?>
                                            </td>
                                            <td class="training-notes">
                                                <?php if(!empty($rawNotes)): ?>
                                                    <div class="evidence-notes-content">
                                                        <?php $__currentLoopData = $notesLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(trim($line) !== ''): ?>
                                                                <?php if($index > 0): ?>
                                                                    <br><br>
                                                                <?php endif; ?>
                                                                <?php echo e($line); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="action-buttons-group">
                                                    <button class="btn-edit" title="Edit" onclick="openEditSubsectionModal(
                                                                                                                                            <?php echo e($subsection->sub_section_id); ?>,
                                                                                                                                            <?php echo e($subsection->section_id); ?>,
                                                                                                                                            '<?php echo e(addslashes($subsection->sub_section)); ?>',
                                                                                                                                            <?php echo e($subsection->max_points ?? ''); ?>,
                                                                                                                                            '<?php echo e(addslashes($subsection->evidence_needed ?? '')); ?>',
                                                                                                                                            '<?php echo e(addslashes($subsection->notes ?? '')); ?>',
                                                                                                                                            <?php echo e($subsection->order_no ?? ''); ?>

                                                                                                                                        )">
                                                        <i class="fas fa-edit"></i>
                                                    </button>

                                                    <button class="btn-delete" title="Delete" onclick="openDeleteSubsectionModal(
                                                                                                                                            <?php echo e($subsection->sub_section_id); ?>,
                                                                                                                                            '<?php echo e(addslashes($subsection->sub_section)); ?>'
                                                                                                                                        )">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        
                        <?php $__currentLoopData = $subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $positions = $subsection->options ?? collect();

                                // Prefer subsection evidence/notes; fallback to section-level
                                $rawEvidence = $subsection->evidence_needed ?: $section->evidence;
                                $rawNotes = $subsection->notes ?: $section->notes;

                                $evidenceLines = preg_split("/\r\n|\n|\r/", $rawEvidence ?? '');
                                $notesLines = preg_split("/\r\n|\n|\r/", $rawNotes ?? '');

                                // For rate-based subsections, show the subsection itself
                                $isRateBased = $subsection->scoring_method === 'rate';
                                $scoreParams = $subsection->score_params ?? [];
                                $rate = $scoreParams['rate'] ?? null;
                                $capPoints = $subsection->cap_points ?? null;

                                // If rate-based and no options, create a display row
                                if ($isRateBased && $positions->isEmpty()) {
                                    $positions = collect([
                                        (object) [
                                            'id' => null,
                                            'label' => $subsection->sub_section,
                                            'points' => $rate,
                                            'order_no' => null,
                                        ],
                                    ]);
                                }

                                $rowCount = max($positions->count(), 1);
                            ?>

                            <?php if($positions->isNotEmpty() || $isRateBased): ?>
                                <div class="table-wrap">
                                    <table class="manage-table">
                                        <thead>
                                            <tr>
                                                <th>Subsection</th>
                                                <th>Position / Title</th>
                                                <th>Points</th>
                                                <th>Evidence Needed</th>
                                                <th>Notes</th>
                                                <?php if(!$isRateBased): ?>
                                                    <th>Actions</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($index === 0): ?>
                                                        <td rowspan="<?php echo e($rowCount); ?>">
                                                            <strong><?php echo e($subsection->sub_section); ?></strong>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td>
                                                        <?php if($isRateBased && $index === 0): ?>
                                                            <?php echo e($subsection->sub_section); ?>

                                                        <?php else: ?>
                                                            <?php echo e($pos->label); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($isRateBased && $index === 0): ?>
                                                            <?php if($rate): ?>
                                                                <?php echo e(rtrim(rtrim(number_format($rate, 1), '0'), '.')); ?>/day
                                                                <?php if($capPoints): ?>
                                                                    (max <?php echo e(rtrim(rtrim(number_format($capPoints, 2), '0'), '.')); ?>

                                                                    points)
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php echo e(rtrim(rtrim(number_format($pos->points, 2), '0'), '.')); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if($index === 0): ?>
                                                        <td rowspan="<?php echo e($rowCount); ?>">
                                                            <?php if(!empty($rawEvidence)): ?>
                                                                <div class="evidence-notes-content">
                                                                    <?php $__currentLoopData = $evidenceLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if(trim($line) !== ''): ?>
                                                                            <?php if($idx > 0): ?>
                                                                                <br><br>
                                                                            <?php endif; ?>
                                                                            <?php echo e($line); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            <?php else: ?>
                                                                —
                                                            <?php endif; ?>
                                                        </td>
                                                        <td rowspan="<?php echo e($rowCount); ?>">
                                                            <?php if(!empty($rawNotes)): ?>
                                                                <div class="evidence-notes-content">
                                                                    <?php $__currentLoopData = $notesLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if(trim($line) !== ''): ?>
                                                                            <?php if($idx > 0): ?>
                                                                                <br><br>
                                                                            <?php endif; ?>
                                                                            <?php echo e($line); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            <?php else: ?>
                                                                —
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if(!$isRateBased): ?>
                                                        <td>
                                                            <div class="action-buttons-group">
                                                                <button class="btn-edit" title="Edit"
                                                                    onclick="openEditRubricModal(
                                                                                                                                                                                                        <?php echo e($pos->id); ?>,
                                                                                                                                                                                                        <?php echo e($subsection->sub_section_id); ?>,
                                                                                                                                                                                                        '<?php echo e(addslashes($pos->label)); ?>',
                                                                                                                                                                                                        <?php echo e($pos->points ?? 0); ?>,
                                                                                                                                                                                                        <?php echo e($pos->order_no ?? ''); ?>,
                                                                                                                                                                                                        '<?php echo e(addslashes($subsection->notes ?? '')); ?>'
                                                                                                                                                                                                    )">
                                                                    <i class="fas fa-edit"></i>
                                                                </button>

                                                                <button class="btn-delete" title="Delete"
                                                                    onclick="openDeleteRubricModal(
                                                                                                                                                                                                        <?php echo e($pos->id); ?>,
                                                                                                                                                                                                        'Leadership',
                                                                                                                                                                                                        '<?php echo e(addslashes($pos->label)); ?>'
                                                                                                                                                                                                    )">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/rubrics/sections/leadership.blade.php ENDPATH**/ ?>