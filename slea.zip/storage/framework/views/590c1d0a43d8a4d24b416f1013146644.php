<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>SLEA - Student Registration</title>
    <link rel="icon" href="<?php echo e(asset('images/osas-logo.png')); ?>?v=<?php echo e(filemtime(public_path('images/osas-logo.png'))); ?>" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <meta id="slea-routes"
        data-programs="<?php echo e(route('ajax.programs')); ?>"
        data-majors="<?php echo e(route('ajax.majors')); ?>"
        data-clusters="<?php echo e(route('ajax.clusters')); ?>"
        data-organizations="<?php echo e(route('ajax.organizations')); ?>"
        data-positions="<?php echo e(route('ajax.positions')); ?>"
        <?php if(\Illuminate\Support\Facades\Route::has('ajax.council.positions')): ?>
        data-council-positions="<?php echo e(route('ajax.council.positions')); ?>"
        <?php endif; ?>
        <?php if(\Illuminate\Support\Facades\Route::has('ajax.academics.map')): ?>
        data-academics-map="<?php echo e(route('ajax.academics.map')); ?>"
        <?php endif; ?>>

    <link href="<?php echo e(asset('css/header.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600;700&display=swap" rel="stylesheet">
</head>

<body class="d-flex flex-column min-vh-100 <?php echo e(session('dark_mode', false) ? 'dark-mode' : ''); ?>">
    <!-- Header -->
    <div class="header-container">
        <div class="header">
            <div class="d-flex align-items-center gap-3">
                <img src="<?php echo e(asset('images/osas-logo.png')); ?>" alt="USeP Logo" height="60">
                <span class="fs-3 fw-bolder logo-text">SLEA</span>
                <div style="width: 1px; height: 40px; background-color: #ccc; margin: 0 0.5rem;"></div>
                <div class="tagline ms-3">
                    <span class="gold1">Empowering</span> <span class="maroon1">Leadership.</span><br>
                    <span class="maroon1">Recognizing</span> <span class="gold1">Excellence.</span>
                </div>
            </div>

            <div class="header-right d-flex align-items-center gap-3">

                <button id="darkModeToggle" class="dark-toggle-btn" title="Toggle Dark Mode">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Registration Content -->
    <div class="register-container">
        <main class="flex-grow-1">
            <div class="container py-1">
                <h4 class="text-maroon mb-1 fs-1 fw-bold">Sign Up!</h4>
                <p class="small fs-5 fw-normal mb-1">
                    Already have an account? <a href="<?php echo e(route('login.show')); ?>">Login here</a>
                </p>

                    <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                        <strong>Please fix the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                <div class="alert alert-success" role="status">
                    <?php echo e(session('status')); ?>

                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('register.store')); ?>" novalidate>
                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" name="guard" value="student">

                    <!-- Step 1: Personal Information -->
                    <div class="form-step active">
                        <h5 class="mb-1">Personal Information</h5>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label" for="last_name">
                                    Last Name <span class="required">*</span>
                                </label>
                                <input
                                    id="last_name"
                                    type="text"
                                    name="last_name"
                                    class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('last_name')); ?>"
                                    required
                                    autocomplete="family-name">
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label" for="first_name">
                                    First Name <span class="required">*</span>
                                </label>
                            <input
                                    id="first_name"
                                type="text"
                                name="first_name"
                                class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('first_name')); ?>"
                                required
                                autocomplete="given-name">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                            <div class="col-md-4">
                                <label class="form-label" for="middle_name">Middle Name</label>
                            <input
                                    id="middle_name"
                            type="text"
                            name="middle_name"
                            class="form-control <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('middle_name')); ?>"
                            autocomplete="additional-name">
                        <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                            <div class="col-md-4">
                                <label class="form-label" for="birth_date">
                                    Birth Date <span class="required">*</span>
                                </label>
                                <input
                                    id="birth_date"
                                    type="date"
                                    name="birth_date"
                                    class="form-control <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('birth_date')); ?>"
                                    required
                                    autocomplete="bday">
                                <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label" for="age">
                                    Age <span class="required">*</span>
                                </label>
                                <input
                                    id="age"
                                    type="text"
                                    name="age"
                                    class="form-control"
                                    readonly
                                    value="<?php echo e(old('age')); ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label" for="email_address">
                                    USeP Email <span class="required">*</span>
                                </label>
                            <input
                                    id="email_address"
                                type="email"
                                    name="email_address"
                                    class="form-control <?php $__errorArgs = ['email_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="example@usep.edu.ph"
                                    value="<?php echo e(old('email_address')); ?>"
                                    required
                                    autocomplete="email">
                                <?php $__errorArgs = ['email_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label" for="contact">
                                    Contact Number <span class="required">*</span>
                                </label>
                                <input
                                    id="contact"
                                    type="text"
                                    name="contact"
                                    class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('contact')); ?>"
                                required
                                    autocomplete="tel">
                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2: Academic Information -->
                    <div class="form-step">
                        <h5 class="mb-1">Academic Information</h5>
                        <div class="row g-3">
                            
                            <div class="col-md-4">
                                <label class="form-label" for="student_id">
                                    Student ID <span class="required">*</span>
                                </label>
                                <input
                                    id="student_id"
                                    type="text"
                                    name="student_id"
                                    class="form-control <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="e.g. 2021-00001"
                                    value="<?php echo e(old('student_id')); ?>"
                                    required
                                    autocomplete="off">
                                <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4">
                                <label class="form-label" for="college_id">
                                    College <span class="required">*</span>
                                </label>
                                <select
                                    name="college_id"
                                    id="college_id"
                                    class="form-select <?php $__errorArgs = ['college_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                    data-old="<?php echo e(old('college_id')); ?>"
                                    autocomplete="organization">
                                    <option value="">Select College</option>
                                    <?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($c->id); ?>"
                                        <?php echo e((string)old('college_id') === (string)$c->id ? 'selected' : ''); ?>>
                                        <?php echo e($c->college_name ?? $c->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['college_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4">
                                <label class="form-label" for="program_id">
                                    Program <span class="required">*</span>
                                </label>
                                <select
                                    name="program_id"
                                    id="program_id"
                                    class="form-select <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                    data-old="<?php echo e(old('program_id')); ?>">
                                    <option value="">Select Program</option>
                                    
                                </select>
                                <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4">
                                <label class="form-label" for="major_id">Major</label>
                                <select
                                    name="major_id"
                                    id="major_id"
                                    class="form-select <?php $__errorArgs = ['major_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-old="<?php echo e(old('major_id')); ?>">
                                    <option value="">Select Major</option>
                                    
                                </select>
                                <?php $__errorArgs = ['major_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4">
                                <label class="form-label" for="year_level">
                                    Year Level <span class="required">*</span>
                                </label>
                                <select
                                    id="year_level"
                                    name="year_level"
                                    class="form-select <?php $__errorArgs = ['year_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required>
                                    <option value="">--</option>
                                    <option value="1" <?php echo e(old('year_level') == '1' ? 'selected' : ''); ?>>1st Year</option>
                                    <option value="2" <?php echo e(old('year_level') == '2' ? 'selected' : ''); ?>>2nd Year</option>
                                    <option value="3" <?php echo e(old('year_level') == '3' ? 'selected' : ''); ?>>3rd Year</option>
                                    <option value="4" <?php echo e(old('year_level') == '4' ? 'selected' : ''); ?>>4th Year</option>
                                    <option value="5" <?php echo e(old('year_level') == '5' ? 'selected' : ''); ?>>5th Year</option>
                                </select>
                                <?php $__errorArgs = ['year_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4">
                                <label class="form-label" for="expected_grad">
                                    Expected Year to Graduate <span class="required">*</span>
                                </label>
                            <input
                                    id="expected_grad"
                                    type="text"
                                    name="expected_grad"
                                    class="form-control"
                                    readonly
                                    value="<?php echo e(old('expected_grad')); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Step 3: Leadership Involvement -->
                    <div class="form-step form-step-scrollable">
                        <h5 class="mb-1 step-title-fixed">Leadership Information</h5>

                        <div class="step-3-scrollable-content">
                        <div class="row g-3">
                            
                            <div class="col-md-6">
                                <label class="form-label" for="leadership_type_id">
                                    Leadership Type <span class="required">*</span>
                                </label>
                                <select
                                    id="leadership_type_id"
                                    name="leadership_type_id"
                                    class="form-select <?php $__errorArgs = ['leadership_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                    data-old="<?php echo e(old('leadership_type_id')); ?>">
                                    <option value="">Select Leadership Type</option>
                                    <?php $__currentLoopData = $leadershipTypes ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($type->id); ?>"
                                        data-requires-org="<?php echo e((int)($type->requires_org ?? 0)); ?>"
                                        data-key="<?php echo e($type->key ?? ''); ?>"
                                        <?php echo e(old('leadership_type_id') == $type->id ? 'selected' : ''); ?>>
                                        <?php echo e($type->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['leadership_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted d-block mt-1">
                                    USG, OSC, LC, CCO, SCO, LGU, LCM, or EAP. For SCO (Student Clubs and Organizations), Cluster &amp; Organization are required.
                                </small>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            
                            <div class="col-md-6" id="cluster_wrap" style="display:none;">
                                <label class="form-label" for="cluster_id">
                                    Cluster <span id="cluster_required_star" class="required" style="display:none;">*</span>
                                </label>
                                <select
                                    id="cluster_id"
                                    name="cluster_id"
                                    class="form-select <?php $__errorArgs = ['cluster_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-old="<?php echo e(old('cluster_id')); ?>">
                                    <option value="">Select Cluster</option>
                                </select>
                                <?php $__errorArgs = ['cluster_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-6" id="org_wrap" style="display:none;">
                                <label class="form-label" for="organization_id">
                                    Organization <span id="org_required_star" class="required" style="display:none;">*</span>
                                </label>
                                <select
                                    id="organization_id"
                                    name="organization_id"
                                    class="form-select <?php $__errorArgs = ['organization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-old="<?php echo e(old('organization_id')); ?>">
                                    <option value="">Select Organization</option>
                                </select>
                                <small id="org_optional_hint" class="text-muted" style="display:none;">Optional for non-CCO.</small>
                                <?php $__errorArgs = ['organization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            
                            <div class="col-md-6">
                                <label class="form-label" for="position_id">
                                    Position Held <span class="required">*</span>
                                </label>
                                <select
                                    id="position_id"
                                    name="position_id"
                                    class="form-select <?php $__errorArgs = ['position_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required
                                    data-old="<?php echo e(old('position_id')); ?>">
                                    <option value="">Select Position</option>
                                </select>
                                <?php $__errorArgs = ['position_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-6">
                                <label class="form-label" for="leadership_status">
                                    Leadership Status <span class="required">*</span>
                                </label>
                                <select
                                    id="leadership_status"
                                    name="leadership_status"
                                    class="form-select <?php $__errorArgs = ['leadership_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required>
                                    <option value="">Select your leadership status</option>
                                    <option value="Active" <?php echo e(old('leadership_status') === 'Active' ? 'selected' : ''); ?>>
                                        Active (Current Officer/Leader)
                                    </option>
                                    <option value="Inactive" <?php echo e(old('leadership_status') === 'Inactive' ? 'selected' : ''); ?>>
                                        Inactive (Former Officer/Leader)
                                    </option>
                                </select>
                                <?php $__errorArgs = ['leadership_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            
                            <div class="col-md-6">
                                <label class="form-label" for="term">
                                    Leadership Term (School Year) <span class="required">*</span>
                                </label>
                                <input
                                    id="term"
                                    type="text"
                                    name="term"
                                    class="form-control <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('term')); ?>"
                                    placeholder="e.g., 2023-2024"
                                    required>
                                <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-6">
                                <label class="form-label" for="issued_by">
                                    Issued By <span class="required">*</span>
                                </label>
                                <input
                                    id="issued_by"
                                    type="text"
                                    name="issued_by"
                                    class="form-control <?php $__errorArgs = ['issued_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('issued_by')); ?>"
                                    required>
                                <?php $__errorArgs = ['issued_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        </div> <!-- End step-3-scrollable-content -->
                    </div>

                    <!-- Step 4: Account Credentials -->
                    <div class="form-step">
                        <h5 class="mb-1">Login Credentials</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="password">
                                    Password <span class="required">*</span>
                                </label>
                                <input
                                    id="password"
                                    type="password"
                                    name="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                    aria-describedby="passwordHelp">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <ul id="passwordHelp" class="password-requirements list-unstyled mt-1 small">
                                    <li id="length" class="text-danger">
                                        <i class="fa-regular fa-circle-xmark me-1"></i> At least 8 characters
                                    </li>
                                    <li id="uppercase" class="text-danger">
                                        <i class="fa-regular fa-circle-xmark me-1"></i> At least 1 uppercase letter
                                    </li>
                                    <li id="lowercase" class="text-danger">
                                        <i class="fa-regular fa-circle-xmark me-1"></i> At least 1 lowercase letter
                                    </li>
                                    <li id="number" class="text-danger">
                                        <i class="fa-regular fa-circle-xmark me-1"></i> At least 1 number
                                    </li>
                                    <li id="special" class="text-danger">
                                        <i class="fa-regular fa-circle-xmark me-1"></i> At least 1 special character
                                    </li>
                                </ul>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label" for="password_confirmation">
                                    Confirm Password <span class="required">*</span>
                                </label>
                            <input
                                    id="password_confirmation"
                                type="password"
                                name="password_confirmation"
                                class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required>
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-check mt-2">
                            <input
                                class="form-check-input <?php $__errorArgs = ['privacy_agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="privacy_agree"
                                type="checkbox"
                                name="privacy_agree"
                                <?php echo e(old('privacy_agree') ? 'checked' : ''); ?>

                                required>
                            <label class="form-check-label" for="privacy_agree">
                                By continuing to browse this website, I agree to the University of Southeastern Philippines'
                                <a href="https://www.usep.edu.ph/usep-data-privacy-statement/" target="_blank" rel="noopener">
                                    Data Privacy Policy
                                </a>.
                            </label>
                            <?php $__errorArgs = ['privacy_agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Step Controls -->
                    <div class="pagination-controls d-flex justify-content-center align-items-center">
                        <button
                            type="button"
                            class="btn btn-secondary px-3 py-2"
                            id="prevBtn"
                            onclick="nextPrev(-1)"
                            disabled
                            style="display: none;">
                            Previous
                    </button>

                        <div class="page-numbers d-flex gap-1" aria-label="form steps">
                            <span class="page-number active">1</span>
                            <span class="page-number">2</span>
                            <span class="page-number">3</span>
                            <span class="page-number">4</span>
                        </div>

                        <button
                            type="button"
                            class="btn btn-primary maroon-btn px-3 py-2"
                            id="nextBtn"
                            onclick="nextPrev(1)">
                            Next
                        </button>
                    </div>
                </form>
            </div>
        </main>

    <div class="floating-tools d-md-none">
            <button id="darkModeToggleFloating" class="floating-btn" title="Toggle Dark Mode">
            <i class="fas fa-moon"></i>
        </button>
        <a href="#" class="floating-btn" title="Send us a message">
                <i class="fa-solid fa-envelope"></i>
        </a>
        </div>
    </div>

    <footer id="page-footer" class="mt-auto text-center py-2 small">
        &copy; <?php echo e(date('Y')); ?> University of Southeastern Philippines. All rights reserved.
        <a href="#" target="_blank">Terms of Use</a> |
        <a href="https://www.usep.edu.ph/usep-data-privacy-statement/" target="_blank">Privacy Policy</a>
    </footer>

    
    <script src="<?php echo e(asset('js/register.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/auth/register.blade.php ENDPATH**/ ?>