<?php $__env->startSection('title', 'Award Report'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Award Report</h1>
            </div>

            
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <div class="controls-section">
                <div class="filter-controls">
                    <div class="filter-group">
                        <label for="college">College</label>
                        <select name="college" id="college" class="form-select" onchange="updatePrograms()">
                            <option value="">All Colleges</option>
                            <option value="College of Education" <?php if(request('college') === 'College of Education'): echo 'selected'; endif; ?>>
                                College of Education</option>
                            <option value="College of Engineering" <?php if(request('college') === 'College of Engineering'): echo 'selected'; endif; ?>>
                                College of Engineering</option>
                            <option value="College of Information and Computing" <?php if(request('college') === 'College of Information and Computing'): echo 'selected'; endif; ?>>College of Information and Computing</option>
                            <option value="College of Business Administration" <?php if(request('college') === 'College of Business Administration'): echo 'selected'; endif; ?>>College of Business Administration</option>
                            <option value="College of Arts and Science" <?php if(request('college') === 'College of Arts and Science'): echo 'selected'; endif; ?>>College of Arts and Science</option>
                            <option value="College of Applied Economics" <?php if(request('college') === 'College of Applied Economics'): echo 'selected'; endif; ?>>College of Applied Economics</option>
                            <option value="College of Technology" <?php if(request('college') === 'College of Technology'): echo 'selected'; endif; ?>>
                                College of Technology</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label for="program">Program</label>
                        <select name="program" id="program" class="form-select">
                            <option value="">All Programs</option>
                            <!-- Programs will be populated dynamically based on selected college -->
                        </select>
                    </div>
                </div>

                <div class="search-controls">
                    <div class="search-group">
                        <input type="text" name="search" id="search" class="form-control"
                            placeholder="Search by name or ID..." value="<?php echo e(request('search')); ?>">
                        <button type="button" class="btn-search-maroon search-btn-attached" id="searchBtn" title="Search">
                            <i class="fas fa-search"></i>
                        </button>
                        <button type="button" class="btn-export-pdf" onclick="exportReport()" id="exportBtn"
                            title="Export PDF">
                            <i class="fas fa-file-pdf"></i> Export
                        </button>
                        <a href="<?php echo e(route('admin.award-report')); ?>" class="btn-clear" title="Clear filters">
                            Clear
                        </a>
                    </div>
                </div>
            </div>

            
            <form method="GET" action="<?php echo e(route('admin.award-report')); ?>" id="filterForm" style="display: none;">
                <input type="hidden" name="college" id="collegeHidden" value="<?php echo e(request('college')); ?>">
                <input type="hidden" name="program" id="programHidden" value="<?php echo e(request('program')); ?>">
                <input type="hidden" name="search" id="searchHidden" value="<?php echo e(request('search')); ?>">
            </form>

            
            <div class="submissions-table-container">
                <h3 class="program-title">SLEA Recipients</h3>

                <table class="table submissions-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>College</th>
                            <th>Program</th>
                            <th>Total Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($student['student_id']); ?></td>
                                <td><?php echo e($student['name']); ?></td>
                                <td><?php echo e($student['college']); ?></td>
                                <td><?php echo e($student['program']); ?></td>
                                <td><?php echo e($student['points_display'] ?? number_format($student['points'] ?? 0, 2) . '/' . number_format($student['max_points'] ?? 100, 2)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">No SLEA recipients found matching the
                                    selected filters.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if($students->hasPages()): ?>
                <div class="pagination-container" data-pagination-container>
                    <div class="pagination-info">
                        Showing <?php echo e($students->firstItem() ?? 0); ?> – <?php echo e($students->lastItem() ?? 0); ?>

                        of <?php echo e($students->total()); ?> entries
                    </div>

                    <div class="unified-pagination">
                        <?php if($students->onFirstPage()): ?>
                            <button class="btn-nav" disabled>
                                <i class="fas fa-chevron-left"></i> Previous
                            </button>
                        <?php else: ?>
                            <a href="<?php echo e($students->previousPageUrl()); ?>" class="btn-nav">
                                <i class="fas fa-chevron-left"></i> Previous
                            </a>
                        <?php endif; ?>

                        <span class="pagination-pages">
                            <?php
                                $currentPage = $students->currentPage();
                                $lastPage = $students->lastPage();
                                $start = max(1, $currentPage - 2);
                                $end = min($lastPage, $currentPage + 2);
                            ?>

                            <?php if($start > 1): ?>
                                <a href="<?php echo e($students->url(1)); ?>" class="page-btn">1</a>
                                <?php if($start > 2): ?>
                                    <span class="page-btn disabled">...</span>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php for($i = $start; $i <= $end; $i++): ?>
                                <?php if($i == $currentPage): ?>
                                    <span class="page-btn active"><?php echo e($i); ?></span>
                                <?php else: ?>
                                    <a href="<?php echo e($students->url($i)); ?>" class="page-btn"><?php echo e($i); ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if($end < $lastPage): ?>
                                <?php if($end < $lastPage - 1): ?>
                                    <span class="page-btn disabled">...</span>
                                <?php endif; ?>
                                <a href="<?php echo e($students->url($lastPage)); ?>" class="page-btn"><?php echo e($lastPage); ?></a>
                            <?php endif; ?>
                        </span>

                        <?php if($students->hasMorePages()): ?>
                            <a href="<?php echo e($students->nextPageUrl()); ?>" class="btn-nav">
                                Next <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php else: ?>
                            <button class="btn-nav" disabled>
                                Next <i class="fas fa-chevron-right"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <link rel="stylesheet" href="<?php echo e(asset('css/pending-submissions.css')); ?>">
    <style>
        /* Award Report Specific Styles */
        .program-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #7E0308;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #7E0308;
        }

        body.dark-mode .program-title {
            color: #F9BD3D;
            border-bottom-color: #F9BD3D;
        }

        .btn-export-pdf {
            background-color: #7E0308;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 0.5rem 1rem;
            height: 38px;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .btn-export-pdf:hover {
            background-color: #5a0206;
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(126, 3, 8, 0.3);
        }

        .btn-export-pdf:active {
            transform: translateY(0);
        }

        body.dark-mode .btn-export-pdf {
            background-color: #7E0308;
        }

        body.dark-mode .btn-export-pdf:hover {
            background-color: #9a040a;
        }

        /* Filter group width adjustments */
        .filter-group select {
            width: 200px;
            max-width: 200px;
            min-width: 150px;
        }

        /* Search input width */
        .search-group .form-control {
            max-width: 300px;
        }

        /* Table adjustments for sidebar */
        .submissions-table-container {
            margin-top: 1.5rem;
        }

        /* Pagination info styling */
        .pagination-info {
            font-size: 0.9rem;
            color: #6b7280;
            margin-bottom: 0.75rem;
        }

        body.dark-mode .pagination-info {
            color: #9ca3af;
        }
    </style>

    <script>
        // College-Program mapping
        const collegePrograms = {
            'College of Education': ['BTVTED', 'BPED', 'BSED', 'MAED', 'PhD Education'],
            'College of Engineering': ['BSCE', 'BSEE', 'BSME', 'BSIE', 'BSCpE', 'BSArch'],
            'College of Information and Computing': ['BSIT', 'BSCS', 'BSIS', 'BSEMC'],
            'College of Business Administration': ['BSBA', 'BSA', 'BSMA', 'BSHRM', 'BSHM'],
            'College of Arts and Science': ['BS Biology', 'BS Chemistry', 'BS Physics', 'BS Mathematics', 'BA English', 'BA History', 'BA Political Science'],
            'College of Applied Economics': ['BS Economics', 'BS Agricultural Economics', 'BS Development Economics'],
            'College of Technology': ['BS Industrial Technology', 'BS Food Technology', 'BS Electronics Technology']
        };

        function updatePrograms() {
            const collegeSelect = document.getElementById('college');
            const programSelect = document.getElementById('program');
            const collegeHidden = document.getElementById('collegeHidden');
            const programHidden = document.getElementById('programHidden');
            const selectedCollege = collegeSelect.value;
            const currentProgram = '<?php echo e(request('program')); ?>';

            // Update hidden input
            if (collegeHidden) {
                collegeHidden.value = selectedCollege;
            }

            // Clear existing options
            programSelect.innerHTML = '<option value="">All Programs</option>';

            // Add programs based on selected college
            if (selectedCollege && collegePrograms[selectedCollege]) {
                collegePrograms[selectedCollege].forEach(program => {
                    const option = document.createElement('option');
                    option.value = program;
                    option.textContent = program;
                    if (program === currentProgram) {
                        option.selected = true;
                    }
                    programSelect.appendChild(option);
                });
            }

            // Update hidden program input
            if (programHidden) {
                programHidden.value = programSelect.value;
            }
        }

        function exportReport() {
            // Get current filter values
            const college = document.getElementById('college').value;
            const program = document.getElementById('program').value;
            const search = document.getElementById('search').value;

            // Build export URL with filters
            let exportUrl = '<?php echo e(route("admin.award-report.export")); ?>?';
            const params = new URLSearchParams();

            if (college) params.append('college', college);
            if (program) params.append('program', program);
            if (search) params.append('search', search);

            exportUrl += params.toString();

            // Open export in new window/tab
            window.open(exportUrl, '_blank');
        }

        // Handle form submission
        document.addEventListener('DOMContentLoaded', function () {
            updatePrograms();

            // Sync visible inputs with hidden form inputs
            const collegeSelect = document.getElementById('college');
            const programSelect = document.getElementById('program');
            const searchInput = document.getElementById('search');
            const filterForm = document.getElementById('filterForm');

            if (collegeSelect) {
                collegeSelect.addEventListener('change', function () {
                    updatePrograms();
                });
            }

            if (programSelect) {
                programSelect.addEventListener('change', function () {
                    const programHidden = document.getElementById('programHidden');
                    if (programHidden) {
                        programHidden.value = programSelect.value;
                    }
                });
            }

            if (searchInput) {
                searchInput.addEventListener('input', function () {
                    const searchHidden = document.getElementById('searchHidden');
                    if (searchHidden) {
                        searchHidden.value = searchInput.value;
                    }
                });
            }

            // Handle search button click
            const searchBtn = document.getElementById('searchBtn');
            if (searchBtn && filterForm) {
                searchBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    // Update hidden inputs with current values
                    const collegeHidden = document.getElementById('collegeHidden');
                    const programHidden = document.getElementById('programHidden');
                    const searchHidden = document.getElementById('searchHidden');

                    if (collegeHidden && collegeSelect) collegeHidden.value = collegeSelect.value;
                    if (programHidden && programSelect) programHidden.value = programSelect.value;
                    if (searchHidden && searchInput) searchHidden.value = searchInput.value;

                    filterForm.submit();
                });
            }

            // Handle filter dropdown changes - auto-submit
            if (collegeSelect) {
                collegeSelect.addEventListener('change', function () {
                    updatePrograms();
                    // Optionally auto-submit on college change
                    // const collegeHidden = document.getElementById('collegeHidden');
                    // if (collegeHidden) collegeHidden.value = collegeSelect.value;
                    // filterForm.submit();
                });
            }
        });
    </script>
    <script src="<?php echo e(asset('js/admin_pagination.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/award-report.blade.php ENDPATH**/ ?>