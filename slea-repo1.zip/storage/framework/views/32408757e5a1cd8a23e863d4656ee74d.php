<?php $__env->startComponent('mail::message'); ?>
# SLEA Account Approved
<img src="<?php echo new \Illuminate\Support\EncodedHtmlString(asset('images/osas-logo.png')); ?>" alt="SLEA Logo"
    style="max-width:150px; margin:20px auto; display:block;">

Dear <?php echo new \Illuminate\Support\EncodedHtmlString($user->first_name); ?>,

Your **Student Leadership Excellence Awards (SLEA)** account has been **approved**.

You may now log in to the SLEA portal using your USeP email:

**<?php echo new \Illuminate\Support\EncodedHtmlString($user->email); ?>**

<?php $__env->startComponent('mail::button', ['url' => url('/login')]); ?>
Go to SLEA Portal
<?php echo $__env->renderComponent(); ?>

If you believe this email was sent to you in error, please contact your OSAS office.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/emails/account_approved.blade.php ENDPATH**/ ?>