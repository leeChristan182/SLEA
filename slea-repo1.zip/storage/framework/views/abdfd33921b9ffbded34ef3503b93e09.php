<?php $__env->startSection('title', 'Student Revalidation Queue'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="main-content">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="mb-0">Student Revalidation Queue</h2>
            </div>

            
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($rows->isEmpty()): ?>
                <div class="alert alert-info mt-3">
                    There are currently no students flagged for revalidation.
                </div>
            <?php else: ?>
                <div class="table-responsive mt-3">
                    <table class="table table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 70px;">ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Expected Grad Year</th>
                                <th>Eligibility Status</th>
                                <th>Last Updated</th>
                                <th style="width: 260px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    // $row is StudentAcademic, with related User
                                    $user = $row->user;
                                ?>

                                <tr>
                                    
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($row->expected_grad_year ?? '—'); ?></td>
                                    <td>
                                        <?php
                                            $status = (string) $row->eligibility_status;
                                        ?>

                                        <?php if($status === 'needs_revalidation'): ?>
                                            <span class="badge bg-warning text-dark">Needs Revalidation</span>
                                        <?php elseif($status === 'under_review'): ?>
                                            <span class="badge bg-info text-dark">Under Review</span>
                                        <?php elseif($status === 'eligible'): ?>
                                            <span class="badge bg-success">Eligible</span>
                                        <?php elseif($status === 'ineligible'): ?>
                                            <span class="badge bg-danger">Ineligible</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo e(ucfirst($status)); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(\Carbon\Carbon::parse($row->updated_at)->format('M d, Y')); ?></td>

                                    <td>
                                        
                                        <?php if(method_exists($row, 'hasCor') ? $row->hasCor() : !empty($row->certificate_of_registration_path)): ?>
                                            <a href="<?php echo e(route('admin.revalidation.cor', $user->id)); ?>"
                                                class="btn btn-outline-primary btn-sm me-1" target="_blank">
                                                View COR
                                            </a>
                                        <?php else: ?>
                                            <span class="badge bg-secondary me-1">No COR</span>
                                        <?php endif; ?>

                                        
                                        <button type="button" class="btn btn-success btn-sm me-1" data-bs-toggle="modal"
                                            data-bs-target="#approveRevalModal<?php echo e($user->id); ?>">
                                            Approve
                                        </button>

                                        
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#rejectRevalModal<?php echo e($user->id); ?>">
                                            Reject
                                        </button>
                                    </td>
                                </tr>

                                
                                <div class="modal fade" id="approveRevalModal<?php echo e($user->id); ?>" tabindex="-1"
                                    aria-labelledby="approveRevalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <form method="POST" action="<?php echo e(route('admin.revalidation.approve', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>

                                                <div class="modal-header bg-success text-white">
                                                    <h5 class="modal-title" id="approveRevalLabel<?php echo e($user->id); ?>">
                                                        Approve Student Revalidation
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>

                                                <div class="modal-body">
                                                    <p class="mb-2">
                                                        Are you sure you want to mark this student as
                                                        <strong>eligible</strong> again?
                                                    </p>
                                                    <p class="mb-0">
                                                        <strong><?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?></strong><br>
                                                        <small class="text-muted"><?php echo e($user->email); ?></small>
                                                    </p>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="submit" class="btn btn-success">
                                                        Yes, Approve
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="modal fade" id="rejectRevalModal<?php echo e($user->id); ?>" tabindex="-1"
                                    aria-labelledby="rejectRevalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <form method="POST" action="<?php echo e(route('admin.revalidation.reject', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>

                                                <div class="modal-header bg-danger text-white">
                                                    <h5 class="modal-title" id="rejectRevalLabel<?php echo e($user->id); ?>">
                                                        Reject Student Revalidation
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>

                                                <div class="modal-body">
                                                    <p class="mb-2">
                                                        This will mark the student as <strong>ineligible</strong>.
                                                    </p>
                                                    <p class="mb-3">
                                                        <strong><?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?></strong><br>
                                                        <small class="text-muted"><?php echo e($user->email); ?></small>
                                                    </p>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="submit" class="btn btn-danger">
                                                        Yes, Reject
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    <?php echo e($rows->links()); ?>

                </div>
            <?php endif; ?>

        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/revalidation.blade.php ENDPATH**/ ?>