<?php $__env->startSection('title', 'Criteria & Point System'); ?>

<?php $__env->startSection('content'); ?>
    <div class="rubric-main-container">
        <div class="container">
            <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="main-content">
                <div class="rubric-content">

                    
                    <div class="rubric-header-nav">
                        <a href="<?php echo e(route('student.performance')); ?>" class="btn-back">
                            <i class="fa-solid fa-arrow-left"></i>
                            <span>Back to Performance Summary</span>
                        </a>
                    </div>

                    
                    <h1 class="rubric-main-title">SLEA Criteria &amp; Point System</h1>

                    <p class="rubric-heading">
                        Review how your submissions will be evaluated for each SLEA category.
                        Use the category shortcuts below to jump between sections.
                    </p>

                    
                    <div class="mb-3">
                        <div class="tab-nav" id="criteriaTabs"
                            style="flex-wrap: wrap; overflow-x: visible; gap:.5rem; width:100%; justify-content:flex-start;">

                            <button class="btn btn-disable" data-filter="all">
                                All Categories
                            </button>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="btn" data-filter="cat-<?php echo e($cat->id); ?>">
                                    <?php echo e($loop->iteration); ?>. <?php echo e($cat->title); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <section class="rubric-section criteria-category" data-category-key="cat-<?php echo e($cat->id); ?>">

                            
                            <div class="rubric-heading d-flex justify-content-between align-items-center">
                                <div><?php echo e($loop->iteration); ?>. <?php echo e($cat->title); ?></div>
                                <div>
                                    <?php if(!is_null($cat->min_required_points)): ?>
                                        <span class="badge badge--red ms-1">
                                            Min required:
                                            <?php echo e(rtrim(rtrim(number_format($cat->min_required_points, 2), '0'), '.')); ?> pts
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <?php if($cat->description): ?>
                                <div class="account-summary mb-3">
                                    <div class="summary-row">
                                        <span class="summary-label">Description</span>
                                        <span class="summary-value"><?php echo e($cat->description); ?></span>
                                    </div>
                                </div>
                            <?php endif; ?>

                            
                            <?php $__empty_2 = true; $__currentLoopData = $cat->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="subsection">

                                    <div class="subsection-title">
                                        <?php echo e($section->title); ?>

                                        <?php if(!is_null($section->max_points)): ?>
                                            <span class="text-muted ms-1">
                                                (Section max:
                                                <?php echo e(rtrim(rtrim(number_format($section->max_points, 2), '0'), '.')); ?> pts)
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="table-responsive rubric-table-wrapper">
                                        <table class="manage-table">
                                            <thead>
                                                <tr>
                                                    <th style="width: 24%">Subsection</th>
                                                    <th style="width: 30%">Positions / Options</th>
                                                    <th style="width: 12%">Points</th>
                                                    <th style="width: 17%">Evidence Needed</th>
                                                    <th style="width: 17%">Notes</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php $__empty_3 = true; $__currentLoopData = $section->subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <?php
                                                        $options = $sub->options;
                                                        $optionCount = max(1, $options->count());

                                                        // SAFE decode for score_params (can be array or JSON string)
                                                        if (is_array($sub->score_params)) {
                                                            $params = $sub->score_params;
                                                        } elseif (is_string($sub->score_params) && trim($sub->score_params) !== '') {
                                                            $params = json_decode($sub->score_params, true);
                                                        } else {
                                                            $params = null;
                                                        }

                                                        // Fallback points text for subsections without options
                                                        $noOptionDisplay = null;
                                                        if (!is_null($sub->max_points)) {
                                                            $noOptionDisplay =
                                                                rtrim(rtrim(number_format($sub->max_points, 2), '0'), '.') . ' pts';
                                                        } elseif (!is_null($sub->cap_points)) {
                                                            $noOptionDisplay =
                                                                'Up to ' .
                                                                rtrim(rtrim(number_format($sub->cap_points, 2), '0'), '.') .
                                                                ' pts';
                                                        } elseif ($params && isset($params['rate'])) {
                                                            $noOptionDisplay =
                                                                rtrim(rtrim(number_format($params['rate'], 2), '0'), '.') .
                                                                ' pts per ' . ($sub->unit ?: 'unit');
                                                        }
                                                    ?>

                                                    
                                                    <tr class="criteria-row">

                                                        
                                                        <td rowspan="<?php echo e($optionCount); ?>">
                                                            <strong><?php echo e($sub->sub_section); ?></strong>
                                                        </td>

                                                        
                                                        <td style="padding:6px 10px; border-bottom:1px solid #e3e3e3;">
                                                            <?php if($options->count()): ?>
                                                                <?php echo e($options[0]->label); ?>

                                                            <?php else: ?>
                                                                <span class="text-muted">No specific options listed.</span>
                                                            <?php endif; ?>
                                                        </td>

                                                        
                                                        <td style="padding:6px 10px; border-bottom:1px solid #e3e3e3;">
                                                            <?php if($options->count()): ?>
                                                                <?php $opt = $options[0]; ?>
                                                                <?php if(!is_null($opt->points)): ?>
                                                                    <?php echo e(rtrim(rtrim(number_format($opt->points, 2), '0'), '.')); ?> pts
                                                                <?php else: ?>
                                                                    —
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php echo e($noOptionDisplay ?? '—'); ?>

                                                            <?php endif; ?>
                                                        </td>

                                                        
                                                        <td rowspan="<?php echo e($optionCount); ?>">
                                                            <?php if($sub->evidence_needed): ?>
                                                                <?php echo nl2br(e($sub->evidence_needed)); ?>

                                                            <?php elseif($section->evidence): ?>
                                                                <?php echo nl2br(e($section->evidence)); ?>

                                                            <?php else: ?>
                                                                <span class="text-muted">See category guidelines.</span>
                                                            <?php endif; ?>
                                                        </td>

                                                        
                                                        <td rowspan="<?php echo e($optionCount); ?>">
                                                            <?php if($sub->notes): ?>
                                                                <?php echo nl2br(e($sub->notes)); ?>

                                                            <?php elseif($section->notes): ?>
                                                                <?php echo nl2br(e($section->notes)); ?>

                                                            <?php else: ?>
                                                                <span class="text-muted">—</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>

                                                    
                                                    <?php if($options->count() > 1): ?>
                                                        <?php $__currentLoopData = $options->slice(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="padding:6px 10px; border-bottom:1px solid #e3e3e3;">
                                                                    <?php echo e($opt->label); ?>

                                                                </td>
                                                                <td style="padding:6px 10px; border-bottom:1px solid #e3e3e3;">
                                                                    <?php if(!is_null($opt->points)): ?>
                                                                        <?php echo e(rtrim(rtrim(number_format($opt->points, 2), '0'), '.')); ?> pts
                                                                    <?php else: ?>
                                                                        —
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted">
                                                            No subsections configured for this section yet.
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>

                                        </table>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="alert alert-light mt-2">
                                    No sections configured under this category yet.
                                </div>
                            <?php endif; ?>

                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-info mt-4">
                            Criteria are not yet configured. Please check again later.
                        </div>
                    <?php endif; ?>

                </div>
            </main>
        </div>
    </div>

    
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const tabs = document.querySelectorAll('#criteriaTabs .btn');
                const sections = document.querySelectorAll('.criteria-category');

                let activeFilter = 'all';

                function applyFilters() {
                    sections.forEach(section => {
                        const matches = (activeFilter === 'all') ||
                            (section.dataset.categoryKey === activeFilter);
                        section.style.display = matches ? '' : 'none';
                    });
                }

                tabs.forEach(tab => {
                    tab.addEventListener('click', () => {
                        tabs.forEach(t => t.classList.remove('btn-disable'));
                        tab.classList.add('btn-disable');
                        activeFilter = tab.dataset.filter || 'all';
                        applyFilters();
                    });
                });

                applyFilters();
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/student/criteria.blade.php ENDPATH**/ ?>