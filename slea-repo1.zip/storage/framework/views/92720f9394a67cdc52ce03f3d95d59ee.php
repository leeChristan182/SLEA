<?php
    $categoryKey = 'community';
    $category = App\Models\RubricCategory::with(['sections.subsections'])
        ->where('key', $categoryKey)
        ->first();
?>

<div class="rubric-section">
    <h4 class="rubric-heading">IV. COMMUNITY INVOLVEMENT</h4>

    <p class="rubric-category-description">
        This criterion refers to the student's participation in community activities, civic involvement or
        public service in local, regional, national, and international levels.
    </p>

    <?php if(!$category || $category->sections->isEmpty()): ?>
        <p class="text-muted text-center">No sections found for this category.</p>
    <?php else: ?>
        <?php $__currentLoopData = $category->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $rowCount = max($section->subsections->count(), 1);
                $sectionPrinted = false;
            ?>

            <div class="table-wrap">
                <table class="manage-table">
                    <thead>
                        <tr>
                            <th>Section</th>
                            <th>Subsection</th>
                            <th>Max Points</th>
                            <th>Evidence Needed</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $section->subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // 1) Base numeric values
                                $points = $sub->max_points ?? $sub->cap_points;

                                // 2) If still null and this is rate-based, use rate/day
                                $pointsDisplay = null;
                                if (!is_null($points)) {
                                    $pointsDisplay = rtrim(rtrim(number_format($points, 2), '0'), '.');
                                } else {
                                    $scoreParams = $sub->score_params ?? [];
                                    $rate = $scoreParams['rate'] ?? null;

                                    if ($sub->scoring_method === 'rate' && $rate !== null) {
                                        $pointsDisplay = rtrim(rtrim(number_format($rate, 2), '0'), '.') . '/day';
                                    }
                                }

                                // Evidence/notes fallback: subsection → section
                                $evidenceSource = $sub->evidence_needed ?: $section->evidence;
                                $notesSource = $sub->notes ?: $section->notes;
                            ?>

                            <tr>
                                <?php if(!$sectionPrinted): ?>
                                    <td rowspan="<?php echo e($rowCount); ?>"><strong><?php echo e($section->title); ?></strong></td>
                                    <?php $sectionPrinted = true; ?>
                                <?php endif; ?>

                                <td><?php echo e($sub->sub_section); ?></td>
                                <td><?php echo e($pointsDisplay !== null ? $pointsDisplay : '—'); ?></td>

                                
                                <td>
                                    <?php if(!empty($evidenceSource)): ?>
                                        <div class="evidence-notes-content">
                                            <?php $__currentLoopData = explode("\n", $evidenceSource); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($line) !== ''): ?>
                                                    <?php if($index > 0): ?>
                                                        <br><br>
                                                    <?php endif; ?>
                                                    <?php echo e($line); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>

                                
                                <td>
                                    <?php if(!empty($notesSource)): ?>
                                        <div class="evidence-notes-content">
                                            <?php $__currentLoopData = explode("\n", $notesSource); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($line) !== ''): ?>
                                                    <?php if($index > 0): ?>
                                                        <br><br>
                                                    <?php endif; ?>
                                                    <?php echo e($line); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="action-buttons-group">
                                        <button class="btn-edit" title="Edit" onclick="openEditSubsectionModal(
                                                                        <?php echo e($sub->sub_section_id); ?>,
                                                                        <?php echo e($sub->section_id); ?>,
                                                                        '<?php echo e(addslashes($sub->sub_section)); ?>',
                                                                        <?php echo e($sub->max_points ?? ''); ?>,
                                                                        '<?php echo e(addslashes($sub->evidence_needed ?? '')); ?>',
                                                                        '<?php echo e(addslashes($sub->notes ?? '')); ?>',
                                                                        <?php echo e($sub->order_no ?? ''); ?>

                                                                    )">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        <button class="btn-delete" title="Delete" onclick="openDeleteSubsectionModal(
                                                                        <?php echo e($sub->sub_section_id); ?>,
                                                                        '<?php echo e(addslashes($sub->sub_section)); ?>'
                                                                    )">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/rubrics/sections/community.blade.php ENDPATH**/ ?>