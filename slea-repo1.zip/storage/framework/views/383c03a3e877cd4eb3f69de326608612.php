<?php $__env->startSection('title', 'Student Account Approval'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="main-content">
            <div class="page-header">
                <h1>Student Account Approval</h1>
            </div>

            
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <div class="controls-section">
                <div class="search-controls" style="flex: 0 1 auto; max-width: 500px;">
                    <div class="search-group">
                        <input type="text" id="searchInput" name="q" class="form-control" value="<?php echo e(request('q')); ?>"
                            style="max-width: 300px;">
                        <button type="button" id="searchBtn" class="btn-search-maroon search-btn-attached" title="Search"
                            onclick="handleSearchClick(event)">
                            <i class="fas fa-search"></i>
                        </button>
                        <button type="button" id="clearBtn" class="btn-clear" title="Clear search"
                            onclick="handleClearClick(event)">
                            Clear
                        </button>
                    </div>
                </div>
            </div>

            
            <div class="submissions-table-container">
                <table class="table submissions-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Email</th>
                            <th>Program</th>
                            <th>Year Level</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $acad = $student->studentAcademic;
                            ?>
                            <tr>
                                <td><?php echo e($acad->student_number ?? '—'); ?></td>
                                <td>
                                    <?php echo e($student->last_name); ?>,
                                    <?php echo e($student->first_name); ?>

                                    <?php echo e($student->middle_name); ?>

                                </td>
                                <td><?php echo e($student->email); ?></td>
                                <td><?php echo e($acad->program->name ?? '—'); ?></td>
                                <td><?php echo e($acad->year_level ?? '—'); ?></td>
                                <td>
                                    <div class="action-buttons-group">
                                        <form action="<?php echo e(route('admin.approve', $student)); ?>" method="POST"
                                            class="d-inline approve-form"
                                            data-student-name="<?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="button" class="btn-approve" title="Approve">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>

                                        <form action="<?php echo e(route('admin.reject', $student)); ?>" method="POST"
                                            class="d-inline reject-form"
                                            data-student-name="<?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="button" class="btn-reject" title="Reject">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted" style="padding: 40px;">
                                    No pending student accounts found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if($students->hasPages()): ?>
                <div class="pagination-container" data-pagination-container>
                    <div class="pagination-info">
                        Showing <?php echo e($students->firstItem() ?? 0); ?> – <?php echo e($students->lastItem() ?? 0); ?>

                        of <?php echo e($students->total()); ?> entries
                    </div>

                    <div class="unified-pagination">
                        <?php if($students->onFirstPage()): ?>
                            <button class="btn-nav" disabled>
                                <i class="fas fa-chevron-left"></i> Previous
                            </button>
                        <?php else: ?>
                            <a href="<?php echo e($students->previousPageUrl()); ?>" class="btn-nav">
                                <i class="fas fa-chevron-left"></i> Previous
                            </a>
                        <?php endif; ?>

                        <span class="pagination-pages">
                            <?php
                                $currentPage = $students->currentPage();
                                $lastPage = $students->lastPage();
                                $start = max(1, $currentPage - 2);
                                $end = min($lastPage, $currentPage + 2);
                            ?>

                            <?php if($start > 1): ?>
                                <a href="<?php echo e($students->url(1)); ?>" class="page-btn">1</a>
                                <?php if($start > 2): ?>
                                    <span class="page-btn disabled">...</span>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php for($i = $start; $i <= $end; $i++): ?>
                                <?php if($i == $currentPage): ?>
                                    <span class="page-btn active"><?php echo e($i); ?></span>
                                <?php else: ?>
                                    <a href="<?php echo e($students->url($i)); ?>" class="page-btn"><?php echo e($i); ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if($end < $lastPage): ?>
                                <?php if($end < $lastPage - 1): ?>
                                    <span class="page-btn disabled">...</span>
                                <?php endif; ?>
                                <a href="<?php echo e($students->url($lastPage)); ?>" class="page-btn"><?php echo e($lastPage); ?></a>
                            <?php endif; ?>
                        </span>

                        <?php if($students->hasMorePages()): ?>
                            <a href="<?php echo e($students->nextPageUrl()); ?>" class="btn-nav">
                                Next <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php else: ?>
                            <button class="btn-nav" disabled>
                                Next <i class="fas fa-chevron-right"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <link rel="stylesheet" href="<?php echo e(asset('css/pending-submissions.css')); ?>">
    <style>
        /* Status badges for approve-reject page */
        .status-badge.pending {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffc107;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge.approved {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #28a745;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge.rejected {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #dc3545;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        body.dark-mode .status-badge.pending {
            background-color: #744210;
            color: #f6e05e;
            border-color: #f6e05e;
        }

        body.dark-mode .status-badge.approved {
            background-color: #1e4d2b;
            color: #68d391;
            border-color: #68d391;
        }

        body.dark-mode .status-badge.rejected {
            background-color: #742a2a;
            color: #feb2b2;
            border-color: #feb2b2;
        }

        /* Action buttons group */
        .action-buttons-group {
            display: flex;
            gap: 8px;
            justify-content: center;
            align-items: center;
        }

        .btn-approve,
        .btn-reject {
            width: 35px;
            height: 35px;
            border: none;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            padding: 0;
        }

        .btn-approve {
            background-color: #28a745;
            color: white;
        }

        .btn-approve:hover {
            background-color: #218838;
            transform: translateY(-1px);
        }

        .btn-reject {
            background-color: #dc3545;
            color: white;
        }

        .btn-reject:hover {
            background-color: #c82333;
            transform: translateY(-1px);
        }

        .btn-approve i,
        .btn-reject i {
            font-size: 0.9rem;
        }

        .no-action-text {
            color: #6c757d;
            font-style: italic;
            font-size: 0.85rem;
        }

        body.dark-mode .no-action-text {
            color: #999;
        }

        body.dark-mode .btn-approve {
            background-color: #28a745;
        }

        body.dark-mode .btn-approve:hover {
            background-color: #2d5a2d;
        }

        body.dark-mode .btn-reject {
            background-color: #dc3545;
        }

        body.dark-mode .btn-reject:hover {
            background-color: #8b0000;
        }

        /* Controls section - search only */
        .controls-section {
            justify-content: flex-end;
        }
    </style>
    <script src="<?php echo e(asset('js/admin_pagination.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Search and Clear functionality
        function handleSearchClick(event) {
            event.preventDefault();
            const searchInput = document.getElementById('searchInput');
            const form = document.createElement('form');
            form.method = 'GET';
            form.action = window.location.pathname;

            if (searchInput.value.trim()) {
                const qInput = document.createElement('input');
                qInput.type = 'hidden';
                qInput.name = 'q';
                qInput.value = searchInput.value.trim();
                form.appendChild(qInput);
            }

            document.body.appendChild(form);
            form.submit();
        }

        function handleClearClick(event) {
            event.preventDefault();
            document.getElementById('searchInput').value = '';
            const form = document.createElement('form');
            form.method = 'GET';
            form.action = window.location.pathname;
            document.body.appendChild(form);
            form.submit();
        }

        // Approve/Reject confirmation modals
        document.addEventListener('DOMContentLoaded', function () {
            // Approve button handlers
            document.querySelectorAll('.approve-form').forEach(function (form) {
                const button = form.querySelector('.btn-approve');
                const studentName = form.getAttribute('data-student-name');

                button.addEventListener('click', function (e) {
                    e.preventDefault();

                    Swal.fire({
                        title: 'Approve Student Account?',
                        html: `Are you sure you want to approve the account for <strong>${studentName}</strong>?`,
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonColor: '#28a745',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Yes, Approve',
                        cancelButtonText: 'Cancel',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });

            // Reject button handlers
            document.querySelectorAll('.reject-form').forEach(function (form) {
                const button = form.querySelector('.btn-reject');
                const studentName = form.getAttribute('data-student-name');

                button.addEventListener('click', function (e) {
                    e.preventDefault();

                    Swal.fire({
                        title: 'Reject Student Account?',
                        html: `Are you sure you want to reject the account for <strong>${studentName}</strong>?`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#dc3545',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Yes, Reject',
                        cancelButtonText: 'Cancel',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LEE CHRISTIAN\slea-repo1\resources\views/admin/approve-reject.blade.php ENDPATH**/ ?>