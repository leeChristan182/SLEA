{{-- resources/views/assessor/dashboard.blade.php --}}
@extends('layouts.app')

@section('title', 'Assessor Dashboard')

@section('head')
    <style>
        :root{
            --card:#111827;          /* slate-900-ish */
            --card2:#0b1220;
            --muted:#9ca3af;         /* gray-400 */
            --text:#e5e7eb;          /* gray-200 */
            --line:rgba(255,255,255,.08);
            --good:#22c55e;
            --warn:#f59e0b;
            --bad:#ef4444;
            --info:#60a5fa;
        }

        .ass-wrap{
            max-width: 1200px;
            margin: 0 auto;
            padding: 18px 14px 40px;
        }

        .ass-header{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:14px;
            margin-bottom: 14px;
        }

        .ass-title{
            line-height:1.1;
        }
        .ass-title h1{
            font-size: 1.35rem;
            margin:0;
            color: var(--text);
            font-weight: 800;
            letter-spacing: .2px;
        }
        .ass-title p{
            margin:6px 0 0;
            color: var(--muted);
            font-size: .95rem;
        }

        .ass-actions{
            display:flex;
            flex-wrap:wrap;
            gap:10px;
            justify-content:flex-end;
        }

        .ass-btn{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding: 10px 12px;
            border-radius: 12px;
            border: 1px solid var(--line);
            color: var(--text);
            background: rgba(255,255,255,.03);
            text-decoration:none;
            font-weight: 700;
            font-size: .9rem;
            transition: transform .06s ease, background .2s ease, border-color .2s ease;
            white-space:nowrap;
        }
        .ass-btn:hover{
            background: rgba(255,255,255,.06);
            border-color: rgba(255,255,255,.14);
            transform: translateY(-1px);
            color: var(--text);
        }

        .ass-grid{
            display:grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 12px;
            margin-top: 12px;
        }

        .ass-card{
            grid-column: span 12;
            border: 1px solid var(--line);
            background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
            border-radius: 16px;
            padding: 14px;
            box-shadow: 0 10px 22px rgba(0,0,0,.25);
        }

        .ass-card h3{
            margin:0;
            font-size: 1rem;
            font-weight: 800;
            color: var(--text);
        }
        .ass-card p{
            margin:6px 0 0;
            color: var(--muted);
            font-size: .92rem;
        }

        .stat{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            margin-top: 10px;
        }
        .stat .num{
            font-size: 1.8rem;
            font-weight: 900;
            letter-spacing: .3px;
            color: var(--text);
        }
        .badge{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding: 7px 10px;
            border-radius: 999px;
            border: 1px solid var(--line);
            font-weight: 800;
            font-size: .82rem;
            color: var(--text);
            background: rgba(0,0,0,.15);
        }
        .dot{
            width:9px;height:9px;border-radius:999px;
            display:inline-block;
        }
        .dot.warn{ background: var(--warn); }
        .dot.info{ background: var(--info); }
        .dot.good{ background: var(--good); }

        .ass-card.link-card{
            cursor:pointer;
            text-decoration:none;
        }

        .ass-card.link-card:hover{
            border-color: rgba(255,255,255,.18);
            background: linear-gradient(180deg, rgba(255,255,255,.07), rgba(255,255,255,.03));
        }

        .ass-card .go{
            margin-top: 10px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            color: var(--muted);
            font-size: .9rem;
        }

        .ass-table{
            width:100%;
            border-collapse: collapse;
            margin-top: 10px;
            overflow:hidden;
            border-radius: 12px;
        }
        .ass-table th, .ass-table td{
            padding: 10px 10px;
            border-bottom: 1px solid var(--line);
            color: var(--text);
            font-size: .9rem;
        }
        .ass-table th{
            text-align:left;
            color: var(--muted);
            font-weight: 800;
            font-size: .82rem;
            letter-spacing: .3px;
            text-transform: uppercase;
        }
        .ass-table tr:hover td{
            background: rgba(255,255,255,.03);
        }

        .pill{
            display:inline-flex;
            padding: 5px 10px;
            border-radius: 999px;
            font-weight: 800;
            font-size: .78rem;
            border: 1px solid var(--line);
        }
        .pill.pending{ color: #fbbf24; background: rgba(245,158,11,.12); }
        .pill.submitted{ color: #93c5fd; background: rgba(96,165,250,.12); }
        .pill.finalized{ color: #86efac; background: rgba(34,197,94,.12); }

        @media (min-width: 900px){
            .span-4{ grid-column: span 4; }
            .span-6{ grid-column: span 6; }
            .span-8{ grid-column: span 8; }
            .span-12{ grid-column: span 12; }
        }
    </style>
@endsection

@section('content')
    <div class="ass-wrap">

        @php
            /** @var \App\Models\User $user */
            $user = auth()->user();

            // These can be passed from AssessorController@dashboard()
            $pendingCount = (int) ($pendingCount ?? 0);
            $submittedCount = (int) ($submittedCount ?? 0);
            $finalizedCount = (int) ($finalizedCount ?? 0);

            // Optional lists
            $recentPending = $recentPending ?? collect();
            $recentFinalized = $recentFinalized ?? collect();
        @endphp

        <div class="ass-header">
            <div class="ass-title">
                <h1>Assessor Dashboard</h1>
                <p>
                    Welcome,
                    <strong>{{ trim(($user->first_name ?? '') . ' ' . ($user->last_name ?? '')) ?: ($user->email ?? 'Assessor') }}</strong>.
                    Here’s your review workload overview.
                </p>
            </div>

            <div class="ass-actions">
                <a class="ass-btn" href="{{ route('assessor.submissions.pending-submissions') }}">Pending Reviews</a>
                <a class="ass-btn" href="{{ route('assessor.students.submissions') }}">Student Submissions</a>
                <a class="ass-btn" href="{{ route('assessor.submissions.compiled') }}">Compiled Scores</a>
                <a class="ass-btn" href="{{ route('assessor.final-review.index') }}">Final Review Queue</a>
                <a class="ass-btn" href="{{ route('assessor.profile') }}">My Profile</a>
            </div>
        </div>

        {{-- Flash messages --}}
        @if (session('status'))
            <div class="ass-card" style="border-color: rgba(34,197,94,.35); background: rgba(34,197,94,.08);">
                <strong style="color: var(--text);">{{ session('status') }}</strong>
            </div>
        @endif

        @if ($errors->any())
            <div class="ass-card" style="border-color: rgba(239,68,68,.35); background: rgba(239,68,68,.08);">
                <strong style="color: var(--text);">Please fix the following:</strong>
                <ul style="margin:8px 0 0; color: var(--text);">
                    @foreach ($errors->all() as $e)
                        <li style="color: var(--text); opacity:.95;">{{ $e }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="ass-grid">

            {{-- KPI Cards --}}
            <a href="{{ route('assessor.submissions.pending-submissions') }}" class="ass-card link-card span-4">
                <h3>Pending Reviews</h3>
                <p>Reviews not yet submitted / finalized.</p>

                <div class="stat">
                    <div class="num">{{ $pendingCount }}</div>
                    <div class="badge"><span class="dot warn"></span> Needs action</div>
                </div>

                <div class="go">
                    <span>Open list</span>
                    <span>→</span>
                </div>
            </a>

            {{-- NOTE:
                You don’t have a dedicated route for “Submitted Reviews” and “Finalized Reviews” in your routes list.
                If your pending page already has tabs/filters, keep these cards but link them to the same route with query params.
            --}}
            <a href="{{ route('assessor.submissions.pending-submissions', ['tab' => 'submitted']) }}" class="ass-card link-card span-4">
                <h3>Submitted Reviews</h3>
                <p>Submitted but not finalized (if applicable).</p>

                <div class="stat">
                    <div class="num">{{ $submittedCount }}</div>
                    <div class="badge"><span class="dot info"></span> For checking</div>
                </div>

                <div class="go">
                    <span>Open list</span>
                    <span>→</span>
                </div>
            </a>

            <a href="{{ route('assessor.submissions.pending-submissions', ['tab' => 'finalized']) }}" class="ass-card link-card span-4">
                <h3>Finalized Reviews</h3>
                <p>Completed assessments.</p>

                <div class="stat">
                    <div class="num">{{ $finalizedCount }}</div>
                    <div class="badge"><span class="dot good"></span> Completed</div>
                </div>

                <div class="go">
                    <span>Open list</span>
                    <span>→</span>
                </div>
            </a>

            {{-- Recent Pending --}}
            <div class="ass-card span-6">
                <h3>Recent Pending</h3>
                <p>Quick access to submissions waiting for review.</p>

                @if ($recentPending instanceof \Illuminate\Support\Collection && $recentPending->count())
                    <table class="ass-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th style="width:1%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($recentPending->take(6) as $row)
                                <tr>
                                    <td>
                                        {{ $row->student_name ?? $row->user_name ?? ('#' . $row->id) }}
                                    </td>
                                    <td>{{ $row->category_title ?? $row->category ?? '—' }}</td>
                                    <td><span class="pill pending">Pending</span></td>
                                    <td>
                                        @if (!empty($row->submission_id))
                                            <a class="ass-btn" style="padding:7px 10px; border-radius:10px;"
                                               href="{{ route('assessor.submissions.details', $row->submission_id) }}">
                                                Review
                                            </a>
                                        @elseif (!empty($row->id))
                                            <a class="ass-btn" style="padding:7px 10px; border-radius:10px;"
                                               href="{{ route('assessor.submissions.details', $row->id) }}">
                                                Review
                                            </a>
                                        @else
                                            —
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div style="margin-top:10px; color: var(--muted);">
                        No pending items found.
                    </div>
                @endif
            </div>

            {{-- Recent Finalized --}}
            <div class="ass-card span-6">
                <h3>Recent Finalized</h3>
                <p>Latest completed reviews (for reference).</p>

                @if ($recentFinalized instanceof \Illuminate\Support\Collection && $recentFinalized->count())
                    <table class="ass-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th style="width:1%;">View</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($recentFinalized->take(6) as $row)
                                <tr>
                                    <td>{{ $row->student_name ?? $row->user_name ?? ('#' . $row->id) }}</td>
                                    <td>{{ $row->category_title ?? $row->category ?? '—' }}</td>
                                    <td><span class="pill finalized">Finalized</span></td>
                                    <td>
                                        @if (!empty($row->submission_id))
                                            <a class="ass-btn" style="padding:7px 10px; border-radius:10px;"
                                               href="{{ route('assessor.submissions.details', $row->submission_id) }}">
                                                Open
                                            </a>
                                        @elseif (!empty($row->id))
                                            <a class="ass-btn" style="padding:7px 10px; border-radius:10px;"
                                               href="{{ route('assessor.submissions.details', $row->id) }}">
                                                Open
                                            </a>
                                        @else
                                            —
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div style="margin-top:10px; color: var(--muted);">
                        No finalized items found.
                    </div>
                @endif
            </div>

            {{-- Notes / Reminders --}}
            <div class="ass-card span-12">
                <h3>Reminders</h3>
                <p style="margin-top:10px;">
                    • Use <strong>Pending Reviews</strong> to score and submit assessments.<br>
                    • Use <strong>Student Submissions</strong> to verify student readiness and submission completeness.<br>
                    • Use <strong>Final Review Queue</strong> to queue students for admin final decision once requirements are satisfied.
                </p>
            </div>

        </div>
    </div>
@endsection
