<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class StudentAcademic extends Model
{
    use HasFactory;

    protected $table = 'student_academic';

    // Eligibility statuses (match eligibility_statuses enum table)
    public const ELIGIBILITY_ELIGIBLE           = 'eligible';
    public const ELIGIBILITY_INELIGIBLE         = 'ineligible';
    public const ELIGIBILITY_NEEDS_REVALIDATION = 'needs_revalidation';
    public const ELIGIBILITY_UNDER_REVIEW       = 'under_review';

    // SLEA application statuses (match slea_application_statuses enum table)
    public const SLEA_STATUS_INCOMPLETE        = 'incomplete';
    public const SLEA_STATUS_PENDING_ASSESSOR   = 'pending_assessor_evaluation';
    public const SLEA_STATUS_PENDING_ADMIN      = 'pending_administrative_validation';
    public const SLEA_STATUS_QUALIFIED          = 'qualified';
    public const SLEA_STATUS_NOT_QUALIFIED      = 'not_qualified';
    // add others if you have them (e.g. 'tracking', 'incomplete', etc.)
    protected $fillable = [
        'user_id',
        'student_number',
        'college_id',
        'program_id',
        'major_id',
        'year_level',
        'graduate_prior',
        'expected_grad_year',
        'eligibility_status',
        'revalidated_at',
        'ready_for_rating',
        'ready_for_rating_at',
        'slea_application_status',
        'certificate_of_registration_path'
    ];

    protected $casts = [
        'graduate_prior'     => 'integer',
        'expected_grad_year' => 'integer',
        'revalidated_at'     => 'datetime',

        'ready_for_rating'        => 'boolean',
        'ready_for_rating_at'     => 'datetime',

    ];

    /* ------------ Relationships ------------ */

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function college()
    {
        return $this->belongsTo(College::class);
    }

    public function program()
    {
        return $this->belongsTo(Program::class);
    }

    public function major()
    {
        return $this->belongsTo(Major::class);
    }
    /**
     * Is this student in their expected graduation year?
     */
    /* ------------ SLEA Helpers ------------ */

    public function isGraduatingThisYear(): bool
    {
        if ((int) $this->year_level === 4) {
            return true;
        }

        if ($this->expected_grad_year) {
            return (int) $this->expected_grad_year === (int) now()->year;
        }

        return false;
    }

    public function hasSleaApplication(): bool
    {
        return $this->ready_for_rating || !empty($this->slea_application_status);
    }

    public function canMarkReadyForSlea(): bool
    {
        // Must be graduating (4th year / equivalent)
        if (! $this->isGraduatingThisYear()) {
            return false;
        }

        // Already clicked / in SLEA flow
        if ($this->ready_for_rating) {
            return false;
        }

        if (! empty($this->slea_application_status)) {
            return false;
        }

        return true;
    }

    public function markReadyForSlea(): void
    {
        $this->ready_for_rating        = true;
        $this->ready_for_rating_at     = now();
        $this->slea_application_status = 'pending_assessor_evaluation';
        $this->save();
    }
    public function markReadyForAdminReview(): void
    {
        // enum from slea_application_statuses table
        $this->slea_application_status = 'pending_administrative_validation';
        $this->save();
    }
    // in StudentAcademic.php

    public function markAwarded()
    {
        $this->slea_application_status = 'qualified';
        $this->save();
    }

    public function markNotQualified()
    {
        $this->slea_application_status = 'not_qualified';
        $this->save();
    }
    /**
     * Check if this student has a COR uploaded.
     */
    public function hasCor(): bool
    {
        return !empty($this->certificate_of_registration_path);
    }
    public function corPath(): ?string
    {
        return $this->certificate_of_registration_path ?: null;
    }
}
