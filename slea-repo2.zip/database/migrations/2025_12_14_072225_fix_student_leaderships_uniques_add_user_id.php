<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {

    private function indexExists(string $table, string $indexName): bool
    {
        return !empty(DB::select(
            "SHOW INDEX FROM `{$table}` WHERE Key_name = ?",
            [$indexName]
        ));
    }

    public function up(): void
    {
        Schema::table('student_leaderships', function (Blueprint $table) {

            // ✅ Drop legacy uniques ONLY if they exist
            if ($this->indexExists('student_leaderships', 'uniq_non_org_position_per_term')) {
                $table->dropUnique('uniq_non_org_position_per_term');
            }

            if ($this->indexExists('student_leaderships', 'uniq_org_position_per_term')) {
                $table->dropUnique('uniq_org_position_per_term');
            }

            // ✅ Add correct per-user uniqueness rules
            if (!$this->indexExists('student_leaderships', 'uniq_user_non_org_position_per_term')) {
                $table->unique(
                    ['user_id', 'leadership_type_id', 'position_id', 'term'],
                    'uniq_user_non_org_position_per_term'
                );
            }

            if (!$this->indexExists('student_leaderships', 'uniq_user_org_position_per_term')) {
                $table->unique(
                    ['user_id', 'leadership_type_id', 'organization_id', 'position_id', 'term'],
                    'uniq_user_org_position_per_term'
                );
            }
        });
    }

    public function down(): void
    {
        Schema::table('student_leaderships', function (Blueprint $table) {

            if ($this->indexExists('student_leaderships', 'uniq_user_non_org_position_per_term')) {
                $table->dropUnique('uniq_user_non_org_position_per_term');
            }

            if ($this->indexExists('student_leaderships', 'uniq_user_org_position_per_term')) {
                $table->dropUnique('uniq_user_org_position_per_term');
            }

            // (Optional rollback – safe)
            if (!$this->indexExists('student_leaderships', 'uniq_non_org_position_per_term')) {
                $table->unique(
                    ['leadership_type_id', 'position_id', 'term'],
                    'uniq_non_org_position_per_term'
                );
            }

            if (!$this->indexExists('student_leaderships', 'uniq_org_position_per_term')) {
                $table->unique(
                    ['leadership_type_id', 'organization_id', 'position_id', 'term'],
                    'uniq_org_position_per_term'
                );
            }
        });
    }
};
