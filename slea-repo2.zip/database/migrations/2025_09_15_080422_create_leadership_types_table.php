<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('leadership_types', function (Blueprint $table) {
            $table->id();
            $table->string('key', 120)->unique();   // elective, appointive, designation, training
            $table->unsignedTinyInteger(column: 'order_no')->default(value: 99);
            $table->string('name', 191)->unique();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('leadership_types');
    }
};
